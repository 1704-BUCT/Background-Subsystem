// $(".delbtn").click(function () {
//    return confirm("确认删除？此操作不可恢复");
// });

$(function () {
    $("td").on("click",".delbtn",function () {
        console.log("click invoke...");
        return confirm("确认删除？此操作不可恢复");
    });
    var uids={uids:[]};
    $(".cuid").click(function () {
        uids.uids=[];
        $(".cuid:checked").each(function () {
            uids.uids.push($(this).val());
        });
    });
    $(".delbtns").click(function () {
        if(uids.uids.length<=0) return;
        if(confirm("确认删除被选的信息吗,这个操作不可恢复")){
            var json = JSON.stringify(uids);
            $("#deletes").val(json);
            $("#form1").attr("action","/deletes");
            $("#form1").submit();
        }
    });
});
