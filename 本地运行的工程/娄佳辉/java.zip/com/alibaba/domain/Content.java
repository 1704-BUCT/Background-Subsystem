package com.alibaba.domain;


import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table(name="contents")
public class Content {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer cid;//编号
    @NotNull
    private String title;//名称
    private String timg;//图片
    @Lob
    private String contents;//内容
    @ManyToOne
    @JoinColumn(name="tid")
    private ContentType type;//分类
    private LocalDateTime lastmodify;//修改时间
    @ManyToOne
    @JoinColumn(name="uid")
    private User user;//发布者
    private LocalDateTime cdate;//发布时间
    private Integer visitcount;//访问数量

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTimg() {
        return timg;
    }

    public void setTimg(String timg) {
        this.timg = timg;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String content) {
        this.contents = contents;
    }

    public ContentType getType() {
        return type;
    }

    public void setType(ContentType type) {
        this.type = type;
    }

    public LocalDateTime getLastmodify() {
        return lastmodify;
    }

    public void setLastmodify(LocalDateTime lastmodify) {
        this.lastmodify = lastmodify;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public LocalDateTime getCdate() {
        return cdate;
    }

    public void setCdate(LocalDateTime cdate) {
        this.cdate = cdate;
    }

    public Integer getVisitcount() {
        return visitcount;
    }

    public void setVisitcount(Integer visitcount) {
        this.visitcount = visitcount;
    }
}
