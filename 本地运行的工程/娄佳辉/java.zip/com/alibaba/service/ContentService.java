package com.alibaba.service;

import com.alibaba.domain.Content;
import com.alibaba.domain.Search;
import org.springframework.data.domain.Page;
import com.alibaba.domain.ContentType;
import java.awt.print.Pageable;

public interface ContentService {
    public void save(Content content);
    public void delete(Content content);
    public void deleteById(Integer id);
    public void deletes(Iterable<Content> contents);
    public Content findById(Integer id);
    public Page<Content> FindBySearch(Search search, Pageable pageable);

    Page<Content> FindBySearch(Search search, org.springframework.data.domain.Pageable pageable);
}
