package com.alibaba.service;

import com.alibaba.domain.ContentType;

import java.util.List;

public interface ContentTypeService {
    public void save(ContentType type);
    public void delete(ContentType type);
    public void deletes(ContentType type);
    public void deleteById(Integer id);
    public List<ContentType> findByParent(ContentType parent);
    public List<ContentType> findAll();
}
