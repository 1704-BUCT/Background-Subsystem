package com.alibaba.service;
import com.alibaba.domain.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

//import java.awt.print.Pageable;
import java.util.List;

public interface UserService {
    public void save(User u)throws Exception;
    //    public void save(User u);
    public Page<User> findAll(String kw, Pageable pageable);
    public User findById(Integer uid);
    public void deleteById(Integer uid);
    public void deletes(List<User> users);
}
