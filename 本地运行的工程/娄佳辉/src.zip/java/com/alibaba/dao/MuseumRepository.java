package com.alibaba.dao;

import com.alibaba.domain.Museum;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

//自定义查找方法
public interface MuseumRepository extends JpaRepository<Museum,Integer> {
    //这里SpringBoot可以自动生成一些查找方法，实现按字段匹配，命名法用驼峰法，比如方法findById
    //但也可以写自定义的方法
    @Query("select m from Museum m where m.name like concat('%',?1, '%') ")//只要名字含有关键字，就会查到
//    @Query("SELECT u.username FROM User u WHERE u.username LIKE CONCAT('%',:username,'%')")
    public List<Museum> findByName(String name);//根据名字查找博物馆
    @Query("select m from Museum m order by m.avgstar DESC")
    public List<Museum> findAllByOrderByAvgstarDesc();
    @Query("select m from Museum m order by m.avgexhibitionstar DESC")
    public List<Museum> findAllByOrderByAvgexhibitionstarDesc();
    public List<Museum> findAllByOrderByAvgenvironmentstarDesc();
    public List<Museum> findAllByOrderByAvgservicestarDesc();

}
