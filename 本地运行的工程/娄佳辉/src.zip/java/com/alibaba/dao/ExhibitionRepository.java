package com.alibaba.dao;

import com.alibaba.domain.Exhibition;
import com.alibaba.domain.Museum;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ExhibitionRepository extends JpaRepository<Exhibition,Integer> {
    @Query("select m from Exhibition m where m.name like concat('%',?1, '%') ")//只要名字含有关键字，就会查到
//    @Query("SELECT u.username FROM User u WHERE u.username LIKE CONCAT('%',:username,'%')")
    public List<Exhibition> findByName(String name);//根据名字查找博物馆

    Object findAll(Specification<Exhibition> exhibitionSpecification, Pageable pageable);
}
