package com.alibaba.dao;
import com.alibaba.domain.User;
//import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User,Integer> {
    @Query("select u from User u where u.account like ?1 or u.name like ?1 or u.email like ?1 or u.mobile like?1")
    public Page<User> findByKeyword(String kw, Pageable pageable);//自动分页

    @Query("update User u set u.password=?1 where u.uid=?2")//?1表示第一个参数，?2表示第二个参数
    public void modifiyPassword(String pwd,Integer uid);
    //通过账号查询用户，获取唯一的用户
    public Optional<User> findByAccount(String account);
}
