package com.alibaba.dao;

import com.alibaba.domain.Exhibition;
import com.alibaba.domain.News;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface NewsRepository extends JpaRepository<News,Integer> {
    @Query("select m from Exhibition m where m.name like concat('%',?1, '%') ")//只要名字含有关键字，就会查到
//    @Query("SELECT u.username FROM User u WHERE u.username LIKE CONCAT('%',:username,'%')")
    public List<News> findByName(String name);//根据名字查找博物馆
}
