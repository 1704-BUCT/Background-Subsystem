package com.alibaba.dao;

import com.alibaba.domain.Collection;
import com.alibaba.domain.Exhibition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CollectionRepository extends JpaRepository<Collection,Integer> {
    @Query("select m from Collection m where m.name like concat('%',?1, '%') ")//只要名字含有关键字，就会查到
//    @Query("SELECT u.username FROM User u WHERE u.username LIKE CONCAT('%',:username,'%')")
    public List<Collection> findByName(String name);//根据名字查找博物馆
}