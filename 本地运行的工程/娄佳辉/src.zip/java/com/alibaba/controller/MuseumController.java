package com.alibaba.controller;

import com.alibaba.domain.Museum;
import com.alibaba.service.MuseumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author weriss
 */
@RestController

public class MuseumController {
    @Autowired  //自动注入参数（什么参数？）
    private MuseumService museumService;

    @RequestMapping(value="/museum/{id}",method = RequestMethod.GET)
    public Museum findMuseumById(@PathVariable("id") Integer mid){
        Museum mu =museumService.findById(mid);
//        System.out.println(mu);
        return mu;
    }

    @RequestMapping(value="/museum/findAll",method = RequestMethod.GET)
    public List<Museum> listAllMuseums(){
        List<Museum> museumList=museumService.findAll();
        return museumList;
    }

    @RequestMapping(value = "/museum/findByName/{name}", method = RequestMethod.GET)
    public List<Museum> findMuseumByName(@PathVariable("name") String name){
        List<Museum> museumList=museumService.findByName(name);
        return museumList;
    }
}
