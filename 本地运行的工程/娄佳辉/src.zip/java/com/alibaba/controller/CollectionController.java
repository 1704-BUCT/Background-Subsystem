package com.alibaba.controller;

import com.alibaba.domain.Collection;
import com.alibaba.domain.Exhibition;
import com.alibaba.service.CollectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class CollectionController {
    @Autowired  //自动注入参数（什么参数？）
    private CollectionService collectionService;

    @RequestMapping(value="/collection/{id}",method = RequestMethod.GET)
    public Collection findCollectionById(@PathVariable("id") Integer cid){
        Collection e =collectionService.findById(cid);
//        System.out.println(mu);
        return e;
    }

    @RequestMapping(value="/collection/findAll",method = RequestMethod.GET)
    public List<Collection> listAllCollections(){
        List<Collection> collectionList=collectionService.findAll();
        return collectionList;
    }

    @RequestMapping(value = "/collection/findByName/{name}", method = RequestMethod.GET)
    public List<Collection> findCollectionByName(@PathVariable("name") String name){
        List<Collection> collectionList=collectionService.findByName(name);
        return collectionList;
    }
}
