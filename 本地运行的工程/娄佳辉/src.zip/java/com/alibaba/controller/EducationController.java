package com.alibaba.controller;


import com.alibaba.domain.Education;
import com.alibaba.domain.Exhibition;
import com.alibaba.service.EducationService;
import com.alibaba.service.ExhibitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class EducationController {
    @Autowired  //自动注入参数（什么参数？）
    private EducationService educationService;

    @RequestMapping(value="/education/{id}",method = RequestMethod.GET)
    public Education findEducationById(@PathVariable("id") Integer eid){
        Education e =educationService.findById(eid);
//        System.out.println(mu);
        return e;
    }

    @RequestMapping(value="/education/findAll",method = RequestMethod.GET)
    public List<Education> listAllEducations(){
        List<Education> educationlist=educationService.findAll();
        return educationlist;
    }

    @RequestMapping(value = "/education/findByName/{name}", method = RequestMethod.GET)
    public List<Education> findEducationByName(@PathVariable("name") String name){
        List<Education> edcationlist=educationService.findByName(name);
        return edcationlist;
    }
}
