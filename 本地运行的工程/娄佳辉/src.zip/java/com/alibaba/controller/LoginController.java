package com.alibaba.controller;

import com.alibaba.domain.User;
import com.alibaba.domain.UserLogin;
import com.alibaba.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

/*
 * 根据条件查询用户信息
 * @param get请求返回登录表单
 * */
@Controller
public class LoginController {
    @Autowired
    private UserService userService;
    @GetMapping("/login")
    public String login(Model model){
        model.addAttribute("userLogin",new UserLogin());
        return "login";
    }
    @PostMapping("login")
    public String login(@Valid UserLogin user, BindingResult result, HttpSession session, Model model){
        if(result.hasErrors()){
            return "redierct:/login";
        }
        User u=userService.checkUser(user);
       if(u!=null){
           session.setAttribute("user",u);
           return "edituser";//登录成功需要跳转的页面
       }
       model.addAttribute("fail","账号或密码不正确");
       return "redirect:/login";
    }
}
