package com.alibaba.controller;

import com.alibaba.domain.Exhibition;
import com.alibaba.domain.Museum;
import com.alibaba.service.ExhibitionService;
import com.alibaba.service.MuseumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class ExhibitionController {
    @Autowired  //自动注入参数（什么参数？）
    private ExhibitionService exhibitionService;

    @RequestMapping(value="/exhibition/{id}",method = RequestMethod.GET)
    public Exhibition findExhitionById(@PathVariable("id") Integer eid){
        Exhibition e =exhibitionService.findById(eid);
//        System.out.println(mu);
        return e;
    }

    @RequestMapping(value="/exhibition/findAll",method = RequestMethod.GET)
    public List<Exhibition> listAllExhitions(){
        List<Exhibition> exhibitionList=exhibitionService.findAll();
        return exhibitionList;
    }

    @RequestMapping(value = "/exhibition/findByName/{name}", method = RequestMethod.GET)
    public List<Exhibition> findExhibitionByName(@PathVariable("name") String name){
        List<Exhibition> exhibitionList=exhibitionService.findByName(name);
        return exhibitionList;
    }
}
