package com.alibaba.controller;

import com.alibaba.domain.Exhibition;
import com.alibaba.domain.News;
import com.alibaba.service.ExhibitionService;
import com.alibaba.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class NewsController {
    @Autowired  //自动注入参数（什么参数？）
    private NewsService newsService;

    @RequestMapping(value="/news/{id}",method = RequestMethod.GET)
    public News findNewsById(@PathVariable("id") Integer nid){
        News e =newsService.findById(nid);
//        System.out.println(mu);
        return e;
    }

    @RequestMapping(value="/news/findAll",method = RequestMethod.GET)
    public List<News> listAllNews(){
        List<News> newsList=newsService.findAll();
        return newsList;
    }

    @RequestMapping(value = "/news/findByName/{name}", method = RequestMethod.GET)
    public List<News> findExhibitionByName(@PathVariable("name") String name){
        List<News> newsList=newsService.findByName(name);
        return newsList;
    }
}
