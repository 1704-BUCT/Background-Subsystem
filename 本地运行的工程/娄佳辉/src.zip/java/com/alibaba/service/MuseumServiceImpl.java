package com.alibaba.service;

import com.alibaba.dao.MuseumRepository;
import com.alibaba.dao.UserRepository;
import com.alibaba.domain.Museum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service    //告诉springboot这是一个服务类，让它自动扫描
public class MuseumServiceImpl implements MuseumService{
    @Autowired//springboot自动地注入我们需要的实体类对象
    public MuseumRepository museumRepository;

    @Override
    public Museum findById(Integer mid) {
        return museumRepository.findById(mid).get();
    }

    @Override
    public List<Museum> findAll() {
        List<Museum> list = this.museumRepository.findAll();
        return list;
    }

    @Override
    public List<Museum> findByName(String name) {
        List<Museum> list = this.museumRepository.findByName(name);
        return list;
    }
}
