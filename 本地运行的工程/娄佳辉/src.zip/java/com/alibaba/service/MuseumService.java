package com.alibaba.service;

import com.alibaba.domain.Museum;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface MuseumService {
//    public void save(Museum m) throws Exception;
//    public Page<Museum> returnAll(Pageable pageable);
    public Museum findById(Integer mid);
    public List<Museum> findAll();
    public List<Museum> findByName(String name);
    //删除和模糊查找先不写
}
