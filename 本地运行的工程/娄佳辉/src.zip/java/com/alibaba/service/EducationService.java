package com.alibaba.service;

import com.alibaba.domain.Education;
import com.alibaba.domain.Exhibition;

import java.util.List;

public interface EducationService {
    public Education findById(Integer mid);
    public List<Education> findAll();
    public List<Education> findByName(String name);
}
