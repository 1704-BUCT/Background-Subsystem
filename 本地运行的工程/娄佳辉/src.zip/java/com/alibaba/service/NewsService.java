package com.alibaba.service;

import com.alibaba.domain.Museum;
import com.alibaba.domain.News;

import java.util.List;

public interface NewsService {
    public News findById(Integer mid);
    public List<News> findAll();
    public List<News> findByName(String name);
}
