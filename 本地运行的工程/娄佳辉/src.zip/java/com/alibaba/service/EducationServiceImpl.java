package com.alibaba.service;

import com.alibaba.dao.EducationRepository;
import com.alibaba.dao.ExhibitionRepository;
import com.alibaba.domain.Education;
import com.alibaba.domain.Exhibition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EducationServiceImpl implements EducationService {
    @Autowired//springboot自动地注入我们需要的实体类对象
    public EducationRepository educationRepository;

    @Override
    public Education findById(Integer mid) {
        return educationRepository.findById(mid).get();
    }

    @Override
    public List<Education> findAll() {
        List<Education> list = this.educationRepository.findAll();
        return list;
    }

    @Override
    public List<Education> findByName(String name) {
        List<Education> list = this.educationRepository.findByName(name);
        return list;
    }
}
