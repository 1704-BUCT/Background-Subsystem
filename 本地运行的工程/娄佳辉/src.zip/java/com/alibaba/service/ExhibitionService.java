package com.alibaba.service;

import com.alibaba.domain.Content;
import com.alibaba.domain.Exhibition;
import com.alibaba.domain.Search;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;


public interface ExhibitionService {
    public void save(Exhibition e);

    public Exhibition findById(Integer eid);

    public List<Exhibition> findAll();

    public List<Exhibition> findByName(String name);

    Page<Exhibition> FindBySearch(Search search, Pageable pageable);
}
