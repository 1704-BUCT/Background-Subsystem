package com.alibaba.service;

import com.alibaba.dao.CollectionRepository;
import com.alibaba.dao.ExhibitionRepository;
import com.alibaba.domain.Collection;
import com.alibaba.domain.Exhibition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CollectionServiceImpl implements CollectionService {
    @Autowired//springboot自动地注入我们需要的实体类对象
    public CollectionRepository collectionRepository;

    @Override
    public void save(Collection c) {
        collectionRepository.save(c);
    }

    @Override
    public Collection findById(Integer mid) {
        return collectionRepository.findById(mid).get();
    }

    @Override
    public List<Collection> findAll() {
        List<Collection> list = this.collectionRepository.findAll();
        return list;
    }

    @Override
    public List<Collection> findByName(String name) {
        List<Collection> list = this.collectionRepository.findByName(name);
        return list;
    }
}
