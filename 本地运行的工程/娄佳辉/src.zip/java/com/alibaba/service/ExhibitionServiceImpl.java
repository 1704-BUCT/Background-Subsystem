package com.alibaba.service;

import com.alibaba.dao.ExhibitionRepository;
import com.alibaba.dao.MuseumRepository;
import com.alibaba.domain.Content;
import com.alibaba.domain.Exhibition;
import com.alibaba.domain.Museum;
import com.alibaba.domain.Search;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.LocalDateTime;
import java.util.List;
@Service
public class ExhibitionServiceImpl implements ExhibitionService {
    @Autowired//springboot自动地注入我们需要的实体类对象
    public ExhibitionRepository exhibitionRepository;


    @Override
    public void save(Exhibition e) {
         exhibitionRepository.save(e);
    }

    @Override
    public Exhibition findById(Integer eid) {
        return exhibitionRepository.findById(eid).get();
    }

    @Override
    public List<Exhibition> findAll() {
        List<Exhibition> list = this.exhibitionRepository.findAll();
        return list;
    }

    @Override
    public List<Exhibition> findByName(String name) {
        List<Exhibition> list = this.exhibitionRepository.findByName(name);
        return list;
    }

    @Override//关键字查询展览，可增加关键字字段
    public Page<Exhibition> FindBySearch(Search search, Pageable pageable) {
           if(pageable.getSort().isUnsorted()){
               pageable=PageRequest.of(pageable.getPageNumber(),pageable.getPageSize(),Sort.by("eid").descending());
           }
           return (Page<Exhibition>) exhibitionRepository.findAll(new Specification<Exhibition>(){
               @Override
               public Predicate toPredicate(Root<Exhibition> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
                   Predicate p=criteriaBuilder.conjunction();//与关系
                   Predicate b=criteriaBuilder.disjunction();//或关系
                   if(search.getKeyword()!=null&&!"".equals(search.getKeyword())){
                       String kw="%"+search.getKeyword()+"%";
                       Predicate a1=criteriaBuilder.like(root.get("eid").as(String.class),kw);
                       Predicate a2=criteriaBuilder.like(root.get("uid").as(String.class),kw);
                       b.getExpressions().add(a1);
                       b.getExpressions().add(a2);
                   }
                  return p;
               }
           },pageable);
    }
}
