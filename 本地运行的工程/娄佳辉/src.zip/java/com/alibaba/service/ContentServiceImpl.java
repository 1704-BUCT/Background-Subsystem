package com.alibaba.service;

import com.alibaba.dao.ContenRepository;
import com.alibaba.domain.Content;
import com.alibaba.domain.Search;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.alibaba.domain.ContentType;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.swing.text.AbstractDocument;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class ContentServiceImpl implements ContentService {
    @Autowired
    private ContenRepository contenRepository;
    @Override
    public void save(Content content) {
        contenRepository.save(content);
    }

    @Override
    public void delete(Content content) {
        contenRepository.delete(content);
    }

    @Override
    public void deleteById(Integer id) {
        contenRepository.deleteById(id);
    }

    @Override
    @Transactional
    public void deletes(Iterable<Content> contents) {
        contenRepository.deleteAll();
    }

    @Override
    public Content findById(Integer id) {
        Optional<Content> oc=contenRepository.findById(id);
        if(oc.isPresent()){
            return oc.get();
        }
        return null;
    }

    @Override
    public Page<Content> FindBySearch(Search search, java.awt.print.Pageable pageable) {
        return null;
    }

    @Override
    public Page<Content> FindBySearch(Search search, Pageable pageable) {
        if(pageable.getSort().isUnsorted()){
            pageable= PageRequest.of(pageable.getPageNumber(),pageable.getPageSize(), Sort.by("cid").descending());
        }
        return (Page<Content>) contenRepository.findAll(new Specification<Content>() {
            @Override
            public Predicate toPredicate(Root<Content> r, CriteriaQuery<?> q, CriteriaBuilder cb) {
                Predicate p=cb.conjunction();//与关系
                Predicate b=cb.disjunction();//或关系
                if(search.getKeyword()!=null&&!"".equals(search.getKeyword())){
                    String kw="%"+search.getKeyword()+"%";
                    Predicate a1=cb.like(r.get("title").as(String.class),kw);
                    Predicate a2=cb.like(r.get("content").as(String.class),kw);
                    b.getExpressions().add(a1);
                    b.getExpressions().add(a2);
                }//关键字模糊查询,如需要其他字段，可继续添加
                if(search.getSdate()!=null){//如果开始时间存在就添加开始时间
                    Predicate a1=cb.greaterThanOrEqualTo(r.get("cdate").as(LocalDateTime.class),search.getSdate());
                    p.getExpressions().add(a1);
                }
                if(search.getEdate()!=null){//如果结束时间存在就添加结束时间
                    Predicate a1=cb.lessThanOrEqualTo(r.get("cdate").as(LocalDateTime.class),search.getEdate());
                    p.getExpressions().add(a1);
                }
                if(b.getExpressions().size()>0){
                    p.getExpressions().add(b);
                }
                return p;
            }
        },pageable);
    }
}
