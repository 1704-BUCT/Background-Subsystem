package com.alibaba.service;

import com.alibaba.dao.ContenRepository;
import com.alibaba.dao.ContentTypeRepository;
import com.alibaba.domain.ContentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public class ContenTypeServiceImpl implements ContentTypeService{
    @Autowired
    private ContentTypeRepository contentTypeRepositoryRepository;

    @Override
    public void save(ContentType type) {
        contentTypeRepositoryRepository.save(type);
    }

    @Override
    public void delete(ContentType type) {
        contentTypeRepositoryRepository.delete(type);
    }

    @Override
    @Transactional
    public void deletes(ContentType type) {
        contentTypeRepositoryRepository.deleteAll();
    }

    @Override
    public void deleteById(Integer id) {
        contentTypeRepositoryRepository.deleteById(id);
    }

    @Override
    public List<ContentType> findByParent(ContentType parent) {
        return contentTypeRepositoryRepository.findByParent(parent);
    }

    @Override
    public List<ContentType> findAll() {
        return contentTypeRepositoryRepository.findAll();
    }
}
