package com.alibaba.service;

import com.alibaba.dao.ExhibitionRepository;
import com.alibaba.dao.NewsRepository;
import com.alibaba.domain.Exhibition;
import com.alibaba.domain.News;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewsServiceImpl implements NewsService {
    @Autowired//springboot自动地注入我们需要的实体类对象
    public NewsRepository newsRepository;

    @Override
    public News findById(Integer mid) {
        return newsRepository.findById(mid).get();
    }

    @Override
    public List<News> findAll() {
        List<News> list = this.newsRepository.findAll();
        return list;
    }

    @Override
    public List<News> findByName(String name) {
        List<News> list = this.newsRepository.findByName(name);
        return list;
    }
}
