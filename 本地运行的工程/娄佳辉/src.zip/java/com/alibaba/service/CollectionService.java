package com.alibaba.service;

import com.alibaba.domain.Collection;

import java.util.List;

public interface CollectionService {
    public void save(Collection c);
    public Collection findById(Integer cid);
    public List<Collection> findAll();
    public List<Collection> findByName(String name);
}
