package com.alibaba.domain;

import java.time.LocalDateTime;

public class Search {
    private String keyword;//关键字查找
    private LocalDateTime sdate;//起始时间查找
    private LocalDateTime edate;//结束时间查找

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public LocalDateTime getSdate() {
        return sdate;
    }

    public void setSdate(LocalDateTime sdate) {
        this.sdate = sdate;
    }

    public LocalDateTime getEdate() {
        return edate;
    }

    public void setEdate(LocalDateTime edate) {
        this.edate = edate;
    }
}
