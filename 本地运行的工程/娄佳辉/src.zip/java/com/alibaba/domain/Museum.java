package com.alibaba.domain;

import org.springframework.lang.Nullable;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Objects;

@Entity
@Table(name="museums")
public class Museum {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer mid;

    @Column(length=255)
    @NotNull
    private String name;

    @Column(length = 1000)
    private String introduction;

    @Column(length = 100)
    private String opentime;

    @Column(length = 1000)
    private String collection;

    private BigDecimal lng;//经度
    private BigDecimal lat;//纬度

    @Column(length = 255)
    private String address;
    private double avgexhibitionstar;
    private double avgenvironmentstar;
    private double avgservicestar;
    private double avgstar;
    //自动生成get、set方法Alt+insert
    @Column(length = 100)
    private String imgurl;

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }

    public double getAvgexhibitionstar() {
        return avgexhibitionstar;
    }

    public void setAvgexhibitionstar(double avgexhibitionstar) {
        this.avgexhibitionstar = avgexhibitionstar;
    }

    public double getAvgenvironmentstar() {
        return avgenvironmentstar;
    }

    public void setAvgenvironmentstar(double avgenvironmentstar) {
        this.avgenvironmentstar = avgenvironmentstar;
    }

    public double getAvgservicestar() {
        return avgservicestar;
    }

    public void setAvgservicestar(double avgservicestar) {
        this.avgservicestar = avgservicestar;
    }

    public double getAvgstar() {
        return avgstar;
    }

    public void setAvgstar(double avgstar) {
        this.avgstar = avgstar;
    }

    public Integer getMid() {
        return mid;
    }

    public void setMid(Integer mid) {
        this.mid = mid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getOpentime() {
        return opentime;
    }

    public void setOpentime(String opentime) {
        this.opentime = opentime;
    }

    public String getCollection() {
        return collection;
    }

    public void setCollection(String collection) {
        this.collection = collection;
    }

    public BigDecimal getLng() {
        return lng;
    }

    public void setLng(BigDecimal lng) {
        this.lng = lng;
    }

    public BigDecimal getLat() {
        return lat;
    }

    public void setLat(BigDecimal lat) {
        this.lat = lat;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

}
