package com.alibaba.domain;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "news")
public class News {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer nid;

    @NotNull
    @Column(length = 100)
    private String title;

    private String extract;//新闻摘要

    @Column(length = 3000)
    private String content;//新闻内容

    private String url;//新闻来源网址
    private String imgurl;//图片
    private String author;//新闻作者

    private LocalDateTime releasetime;//发布时间
    private LocalDateTime modifytime;//新闻修改时间

    private Integer status=0;//新闻状态
    private Integer nature=0;//正面新闻还是负面新闻
    private Integer commentstatus=0;//表示新闻是否可以评论

    public Integer getNid() {
        return nid;
    }

    public void setNid(Integer nid) {
        this.nid = nid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getExtract() {
        return extract;
    }

    public void setExtract(String extract) {
        this.extract = extract;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public LocalDateTime getReleasetime() {
        return releasetime;
    }

    public void setReleasetime(LocalDateTime releasetime) {
        this.releasetime = releasetime;
    }

    public LocalDateTime getModifytime() {
        return modifytime;
    }

    public void setModifytime(LocalDateTime modifytime) {
        this.modifytime = modifytime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getNature() {
        return nature;
    }

    public void setNature(Integer nature) {
        this.nature = nature;
    }

    public Integer getCommentstatus() {
        return commentstatus;
    }

    public void setCommentstatus(Integer commentstatus) {
        this.commentstatus = commentstatus;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        News news = (News) o;
        return nid.equals(news.nid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nid);
    }
}
