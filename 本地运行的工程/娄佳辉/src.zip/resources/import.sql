INSERT into users (account, password, name, grander, mobile) values('sysadmin','123456','system admin','男','13120172017');
-- SELECT * from users;
INSERT into museums(name, address) value('museum1','address1');
INSERT into museums(name,address,lng,lat) value('museum2','address2',116.34528,39.21028);

-- 如果数据无法插入，可能是设置非空的字段没有值
INSERT into exhibitions(mid,name,address,introduction,imgurl) value(1,'exhibition1','address1','intrduction1','resource/exhibition/img/id0');
INSERT into exhibitions(mid,name,address,introduction,imgurl) value(2,'exhibition2','address2','intrduction2','resource/exhibition/img/id1');

INSERT into collections(name,introduction,museum) value('康熙梨花木床架','introduction1','museum1');

INSERT into educations(name, museum) value('hundreds of people', 'museum1');

INSERT into news(title, status,nature,commentstatus) value('news title 1', 0, 0, 0);